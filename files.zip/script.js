// Simple Pong — Full features:
// - Game modes: First to N, Lives, Timed
// - Save/load settings to localStorage
// - Particle effects on collisions
// - Improved AI difficulty curve (dynamic)

// DOM
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

const leftScoreEl = document.getElementById('leftScore');
const rightScoreEl = document.getElementById('rightScore');
const infoEl = document.getElementById('info');

const difficultyEl = document.getElementById('difficulty');
const keyboardOnlyEl = document.getElementById('keyboardOnly');
const soundToggleEl = document.getElementById('soundToggle');
const volumeEl = document.getElementById('volume');

const mobileControlsEl = document.getElementById('mobileControls');
const btnUp = document.getElementById('btnUp');
const btnDown = document.getElementById('btnDown');

const openMenuBtn = document.getElementById('openMenu');
const menuOverlay = document.getElementById('menuOverlay');
const closeMenuBtn = document.getElementById('closeMenu');
const applyMenuBtn = document.getElementById('applyMenu');

const gameModeEl = document.getElementById('gameMode');
const pointsToWinEl = document.getElementById('pointsToWin');
const livesEachEl = document.getElementById('livesEach');
const timeSecondsEl = document.getElementById('timeSeconds');
const autoSaveEl = document.getElementById('autoSave');

const firstToParams = document.getElementById('firstToParams');
const livesParams = document.getElementById('livesParams');
const timedParams = document.getElementById('timedParams');

// Canvas size
const W = canvas.width;
const H = canvas.height;

// Paddle settings
const paddleWidth = 12;
const paddleHeight = 92;
const paddleSpeed = 7;

// Ball settings (base)
let initialBallSpeedBase = 5;
const maxBallSpeed = 18;

// Game & mode state
let leftPaddle = { x: 20, y: (H - paddleHeight) / 2, vy: 0 };
let rightPaddle = { x: W - 20 - paddleWidth, y: (H - paddleHeight) / 2, vy: 0 };
let ball = { x: W/2, y: H/2, vx: initialBallSpeedBase, vy: 0 };
let leftScore = 0;
let rightScore = 0;
let running = false;
let lastTime = 0;
let serveDirection = 1; // 1 => right, -1 => left

// Mode specific
let mode = 'firstTo'; // 'firstTo' | 'lives' | 'timed'
let pointsToWin = 7;
let livesEach = 3;
let remainingLives = { left: livesEach, right: livesEach };
let timedSeconds = 60;
let matchEndTime = null;

// Input mode flags
let useMouse = true;
let keyboardOnly = false;

// Difficulty parameters
let aiReaction = 1.0;     // how fast AI tries to correct position
let ballSpeedMultiplier = 1.0;

// Audio
let audioCtx = null;
let masterGain = null;
let soundEnabled = true;
let volume = parseFloat(volumeEl.value);

// Touch dragging
let dragging = false;
let draggingId = null;

// Particles
const particles = [];

// Local storage key
const LS_KEY = 'simple-pong-settings-v1';

// Helpers
function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

function nowSeconds() { return Date.now() / 1000; }

// --- Persist settings ---
function saveSettings() {
  const obj = {
    difficulty: difficultyEl.value,
    keyboardOnly: keyboardOnlyEl.checked,
    soundEnabled: soundToggleEl.checked,
    volume: parseFloat(volumeEl.value),
    mode: gameModeEl.value,
    pointsToWin: parseInt(pointsToWinEl.value,10),
    livesEach: parseInt(livesEachEl.value,10),
    timedSeconds: parseInt(timeSecondsEl.value,10),
    autoSave: autoSaveEl.checked
  };
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(obj));
  } catch (e) {
    console.warn('Could not save settings', e);
  }
}

function loadSettings() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return false;
    const obj = JSON.parse(raw);
    if (obj.difficulty) difficultyEl.value = obj.difficulty;
    if (typeof obj.keyboardOnly === 'boolean') keyboardOnlyEl.checked = obj.keyboardOnly;
    if (typeof obj.soundEnabled === 'boolean') soundToggleEl.checked = obj.soundEnabled;
    if (typeof obj.volume === 'number') volumeEl.value = obj.volume;
    if (obj.mode) gameModeEl.value = obj.mode;
    if (typeof obj.pointsToWin === 'number') pointsToWinEl.value = obj.pointsToWin;
    if (typeof obj.livesEach === 'number') livesEachEl.value = obj.livesEach;
    if (typeof obj.timedSeconds === 'number') timeSecondsEl.value = obj.timedSeconds;
    if (typeof obj.autoSave === 'boolean') autoSaveEl.checked = obj.autoSave;
    return true;
  } catch (e) {
    console.warn('Could not load settings', e);
    return false;
  }
}

// --- Sound functions (Web Audio) ---
function ensureAudioContext() {
  if (audioCtx) return;
  audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  masterGain = audioCtx.createGain();
  masterGain.gain.value = volume;
  masterGain.connect(audioCtx.destination);
}

function setVolume(v) {
  volume = v;
  if (masterGain) masterGain.gain.value = v;
}

function playBeep(freq = 440, duration = 0.06, type = 'sine', gain = 0.12) {
  if (!soundEnabled) return;
  try {
    ensureAudioContext();
    const now = audioCtx.currentTime;
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.type = type;
    o.frequency.value = freq;
    g.gain.value = 0;
    o.connect(g);
    g.connect(masterGain);
    o.start(now);
    // envelope
    g.gain.setValueAtTime(0, now);
    g.gain.linearRampToValueAtTime(gain, now + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    o.stop(now + duration + 0.02);
  } catch (e) {
    console.warn('Audio error', e);
  }
}

function playSound(kind) {
  if (!soundEnabled) return;
  switch (kind) {
    case 'paddle':
      playBeep(900, 0.06, 'sine', 0.14);
      break;
    case 'wall':
      playBeep(520, 0.04, 'triangle', 0.10);
      break;
    case 'score':
      playBeep(360, 0.14, 'sawtooth', 0.14);
      setTimeout(() => playBeep(420, 0.12, 'sine', 0.12), 120);
      break;
    default:
      playBeep(660, 0.05);
  }
}

// --- Particles ---
function spawnParticles(x, y, color = '#67d3ff', count = 14, power = 3) {
  for (let i = 0; i < count; i++) {
    const angle = Math.random() * Math.PI * 2;
    const speed = Math.random() * power;
    particles.push({
      x, y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      life: 0.6 + Math.random() * 0.6,
      age: 0,
      size: 1 + Math.random() * 3,
      color
    });
  }
}

function updateParticles(dt) {
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.age += dt;
    p.x += p.vx * dt * 60;
    p.y += p.vy * dt * 60;
    p.vy += 0.04 * dt * 60; // slight gravity
    if (p.age >= p.life) particles.splice(i, 1);
  }
}

function drawParticles() {
  for (const p of particles) {
    const t = 1 - (p.age / p.life);
    ctx.globalAlpha = t * 0.95;
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size * t, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }
}

// --- Game functions ---
function applyDifficulty() {
  const d = difficultyEl.value;
  if (d === 'easy') {
    aiReaction = 0.82;
    ballSpeedMultiplier = 0.92;
    initialBallSpeedBase = 4.2;
  } else if (d === 'normal') {
    aiReaction = 1.0;
    ballSpeedMultiplier = 1.0;
    initialBallSpeedBase = 5;
  } else if (d === 'hard') {
    aiReaction = 1.18;
    ballSpeedMultiplier = 1.15;
    initialBallSpeedBase = 6;
  }
  if (!running) resetBall(serveDirection === 1);
}

function setModeFromUI() {
  mode = gameModeEl.value;
  pointsToWin = parseInt(pointsToWinEl.value, 10) || 7;
  livesEach = parseInt(livesEachEl.value, 10) || 3;
  timedSeconds = parseInt(timeSecondsEl.value, 10) || 60;
}

function startMatch() {
  // reset scores & lives
  leftScore = 0;
  rightScore = 0;
  updateScore();
  remainingLives.left = livesEach;
  remainingLives.right = livesEach;
  matchEndTime = null;
  if (mode === 'timed') {
    matchEndTime = nowSeconds() + timedSeconds;
  }
  resetBall(true);
  running = false;
  infoEl.textContent = 'Press Space or tap canvas to serve';
}

function resetBall(toRight = true) {
  ball.x = W/2;
  ball.y = H/2;
  const angle = (Math.random() * Math.PI / 4) - (Math.PI / 8); // -22.5 to 22.5
  const speed = initialBallSpeedBase * ballSpeedMultiplier;
  ball.vx = (toRight ? 1 : -1) * speed * Math.cos(angle);
  ball.vy = speed * Math.sin(angle);
  running = false;
  infoEl.textContent = 'Press Space or tap canvas to serve';
}

function updateScore() {
  leftScoreEl.textContent = leftScore;
  rightScoreEl.textContent = rightScore;
}

function drawNet() {
  ctx.fillStyle = 'rgba(255,255,255,0.06)';
  const step = 18;
  for (let y = 0; y < H; y += step) {
    ctx.fillRect(W/2 - 2, y + 6, 4, step/2);
  }
}

function draw() {
  // clear
  ctx.clearRect(0,0,W,H);

  drawNet();

  // paddles
  ctx.fillStyle = '#e6f1ff';
  ctx.fillRect(leftPaddle.x, leftPaddle.y, paddleWidth, paddleHeight);
  ctx.fillRect(rightPaddle.x, rightPaddle.y, paddleWidth, paddleHeight);

  // ball
  ctx.beginPath();
  ctx.fillStyle = '#67d3ff';
  ctx.arc(ball.x, ball.y, 8, 0, Math.PI*2);
  ctx.fill();

  // particles (draw above ball and paddles)
  drawParticles();

  // scores
  ctx.fillStyle = 'rgba(230,241,255,0.95)';
  ctx.font = 'bold 36px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(leftScore, W * 0.25, 50);
  ctx.fillText(rightScore, W * 0.75, 50);

  // if timed mode, show time left
  if (mode === 'timed' && matchEndTime) {
    const secondsLeft = Math.max(0, Math.ceil(matchEndTime - nowSeconds()));
    ctx.font = 'bold 16px system-ui, sans-serif';
    ctx.fillText(`Time: ${secondsLeft}s`, W/2, 30);
  }
}

function ae(speed, dt) {
  // adapt speed by frame time; dt in ms
  return speed * (dt / (1000 / 60));
}

function dynamicAIReaction() {
  // improved AI: base aiReaction scaled by score difference and ball speed.
  // If CPU is behind, give a boost. If CPU is far ahead, reduce to balance.
  const scoreDiff = rightScore - leftScore; // positive => CPU ahead
  const scoreFactor = 1 - (Math.tanh(scoreDiff * 0.35) * 0.2); // range ~0.8..1.2 inverted
  const speedFactor = clamp(1 + (Math.abs(ball.vx) - 5) * 0.06, 0.85, 1.35);
  return aiReaction * scoreFactor * speedFactor;
}

function reflectWithPaddle(paddle) {
  const relativeY = (ball.y - (paddle.y + paddleHeight/2)) / (paddleHeight/2);
  const bounceAngle = relativeY * (Math.PI / 3); // up to 60 degrees

  const speed = Math.min(Math.hypot(ball.vx, ball.vy) * 1.06 + 0.2, maxBallSpeed);
  const direction = paddle === leftPaddle ? 1 : -1;

  ball.vx = direction * speed * Math.cos(bounceAngle);
  ball.vy = speed * Math.sin(bounceAngle);

  // avoid extremely small vx
  if (Math.abs(ball.vx) < 2) ball.vx = direction * (ball.vx < 0 ? -2 : 2);

  // spawn particles and sound
  spawnParticles(ball.x, ball.y, '#67d3ff', 16, 3.5);
  playSound('paddle');
}

function checkMatchEnd() {
  // returns winner 'left' | 'right' | null
  if (mode === 'firstTo') {
    if (leftScore >= pointsToWin) return 'left';
    if (rightScore >= pointsToWin) return 'right';
  } else if (mode === 'lives') {
    if (remainingLives.left <= 0) return 'right';
    if (remainingLives.right <= 0) return 'left';
  } else if (mode === 'timed') {
    if (matchEndTime && nowSeconds() >= matchEndTime) {
      if (leftScore > rightScore) return 'left';
      if (rightScore > leftScore) return 'right';
      return 'draw';
    }
  }
  return null;
}

function handleEnd(winner) {
  running = false;
  if (winner === 'draw') {
    infoEl.textContent = `Time's up — Draw! Press Space to restart`;
  } else {
    infoEl.textContent = `${winner === 'left' ? 'Player' : 'CPU'} wins! Press Space to restart`;
  }
  playSound('score');
}

// --- Game loop ---
function step(dt) {
  // Move left paddle (keyboard)
  leftPaddle.y += leftPaddle.vy;
  leftPaddle.y = clamp(leftPaddle.y, 0, H - paddleHeight);

  // Move right paddle (improved AI)
  const centerBall = ball.y;
  const target = centerBall - paddleHeight/2;
  const diff = target - rightPaddle.y;
  const aiBaseSpeed = 3.6 + Math.abs(ball.vx) * 0.08;
  const curReaction = dynamicAIReaction();
  const aiSpeed = aiBaseSpeed * curReaction;
  if (Math.abs(diff) > 6) {
    rightPaddle.y += Math.sign(diff) * ae(aiSpeed, dt);
  } else {
    rightPaddle.y += diff * 0.14;
  }
  rightPaddle.y = clamp(rightPaddle.y, 0, H - paddleHeight);

  if (!running) {
    updateParticles(dt / 1000);
    return;
  }

  // Move ball
  ball.x += ball.vx;
  ball.y += ball.vy;

  // top/bottom collisions
  if (ball.y - 8 <= 0) {
    ball.y = 8;
    ball.vy *= -1;
    spawnParticles(ball.x, ball.y, '#fff', 8, 1.8);
    playSound('wall');
  } else if (ball.y + 8 >= H) {
    ball.y = H - 8;
    ball.vy *= -1;
    spawnParticles(ball.x, ball.y, '#fff', 8, 1.8);
    playSound('wall');
  }

  // Left paddle collision
  if (ball.x - 8 <= leftPaddle.x + paddleWidth) {
    if (ball.y >= leftPaddle.y && ball.y <= leftPaddle.y + paddleHeight && ball.vx < 0) {
      ball.x = leftPaddle.x + paddleWidth + 8; // push out
      reflectWithPaddle(leftPaddle);
    }
  }

  // Right paddle collision
  if (ball.x + 8 >= rightPaddle.x) {
    if (ball.y >= rightPaddle.y && ball.y <= rightPaddle.y + paddleHeight && ball.vx > 0) {
      ball.x = rightPaddle.x - 8;
      reflectWithPaddle(rightPaddle);
    }
  }

  // Score
  if (ball.x < 0) {
    // CPU scores
    rightScore++;
    updateScore();
    playSound('score');
    spawnParticles(12, H/2, '#ff8a8a', 20, 2.6);
    serveDirection = -1;

    if (mode === 'lives') {
      remainingLives.left--;
    }

    // check match end
    const winner = checkMatchEnd();
    if (winner) {
      handleEnd(winner);
      return;
    }

    resetBall(false);
  } else if (ball.x > W) {
    // Player scores
    leftScore++;
    updateScore();
    playSound('score');
    spawnParticles(W-12, H/2, '#8affc6', 20, 2.6);
    serveDirection = 1;

    if (mode === 'lives') {
      remainingLives.right--;
    }

    const winner = checkMatchEnd();
    if (winner) {
      handleEnd(winner);
      return;
    }

    resetBall(true);
  }

  updateParticles(dt / 1000);
}

// --- Input handling ---

// Mouse (move paddle) — disabled when keyboardOnly is true
function onCanvasMouseMove(e) {
  if (keyboardOnly) return;
  const rect = canvas.getBoundingClientRect();
  const y = e.clientY - rect.top;
  useMouse = true;
  leftPaddle.y = clamp(y - paddleHeight / 2, 0, H - paddleHeight);
}

function onCanvasMouseDown() {
  canvas.focus();
  if (!running) {
    running = true;
    infoEl.textContent = '';
  }
}

// Keyboard
const keysDown = {};
window.addEventListener('keydown', (e) => {
  if (["ArrowUp","ArrowDown","Space"].includes(e.code)) {
    e.preventDefault();
  }
  if (e.code === 'ArrowUp') {
    leftPaddle.vy = -paddleSpeed;
    useMouse = false;
    keysDown.ArrowUp = true;
  } else if (e.code === 'ArrowDown') {
    leftPaddle.vy = paddleSpeed;
    useMouse = false;
    keysDown.ArrowDown = true;
  } else if (e.code === 'Space') {
    if (!running) {
      // If match finished, restart match
      if (checkMatchEnd()) {
        startMatch();
      }
      running = true;
      infoEl.textContent = '';
      if (!audioCtx) ensureAudioContext();
    } else {
      running = !running;
      infoEl.textContent = running ? '' : 'Paused — press Space to resume';
    }
    e.preventDefault();
  }
});

window.addEventListener('keyup', (e) => {
  if (e.code === 'ArrowUp') {
    keysDown.ArrowUp = false;
    if (!keysDown.ArrowDown) leftPaddle.vy = 0;
    else leftPaddle.vy = paddleSpeed;
  } else if (e.code === 'ArrowDown') {
    keysDown.ArrowDown = false;
    if (!keysDown.ArrowUp) leftPaddle.vy = 0;
    else leftPaddle.vy = -paddleSpeed;
  }
});

// Touch handling for dragging paddle (unless keyboardOnly)
canvas.addEventListener('touchstart', (ev) => {
  if (keyboardOnly) return;
  ev.preventDefault();
  for (let t of ev.changedTouches) {
    const rect = canvas.getBoundingClientRect();
    const x = t.clientX - rect.left;
    const y = t.clientY - rect.top;
    if (x < W/2) {
      dragging = true;
      draggingId = t.identifier;
      leftPaddle.y = clamp(y - paddleHeight / 2, 0, H - paddleHeight);
    } else {
      // Right half tap serves
      if (!running) {
        running = true;
        infoEl.textContent = '';
      }
    }
  }
}, {passive:false});

canvas.addEventListener('touchmove', (ev) => {
  if (keyboardOnly || !dragging) return;
  ev.preventDefault();
  for (let t of ev.changedTouches) {
    if (t.identifier === draggingId) {
      const rect = canvas.getBoundingClientRect();
      const y = t.clientY - rect.top;
      leftPaddle.y = clamp(y - paddleHeight / 2, 0, H - paddleHeight);
    }
  }
}, {passive:false});

canvas.addEventListener('touchend', (ev) => {
  if (keyboardOnly) return;
  for (let t of ev.changedTouches) {
    if (t.identifier === draggingId) {
      dragging = false;
      draggingId = null;
    }
  }
});

// Mobile on-screen buttons (touch)
let mobileBtnInterval = null;
function mobileBtnStart(dir) {
  leftPaddle.vy = dir * paddleSpeed;
  mobileBtnInterval = setInterval(() => {
    leftPaddle.y = clamp(leftPaddle.y + leftPaddle.vy, 0, H - paddleHeight);
  }, 16);
}
function mobileBtnEnd() {
  leftPaddle.vy = 0;
  if (mobileBtnInterval) {
    clearInterval(mobileBtnInterval);
    mobileBtnInterval = null;
  }
}

btnUp.addEventListener('touchstart', (e) => { e.preventDefault(); mobileBtnStart(-1); }, {passive:false});
btnUp.addEventListener('touchend', (e) => { e.preventDefault(); mobileBtnEnd(); }, {passive:false});
btnDown.addEventListener('touchstart', (e) => { e.preventDefault(); mobileBtnStart(1); }, {passive:false});
btnDown.addEventListener('touchend', (e) => { e.preventDefault(); mobileBtnEnd(); }, {passive:false});

// Prevent arrow keys from scrolling page
window.addEventListener('keydown', (e) => {
  if (["ArrowUp","ArrowDown","Space"].includes(e.code)) {
    e.preventDefault();
  }
}, {passive:false});

// Canvas mouse listeners
canvas.addEventListener('mousemove', onCanvasMouseMove);
canvas.addEventListener('mousedown', onCanvasMouseDown);

// Settings UI handlers
difficultyEl.addEventListener('change', () => {
  applyDifficulty();
  if (autoSaveEl.checked) saveSettings();
});

keyboardOnlyEl.addEventListener('change', () => {
  keyboardOnly = keyboardOnlyEl.checked;
  if (keyboardOnly) {
    mobileControlsEl.classList.add('hidden');
  } else {
    mobileControlsEl.classList.remove('hidden');
  }
  if (autoSaveEl.checked) saveSettings();
});

soundToggleEl.addEventListener('change', () => {
  soundEnabled = soundToggleEl.checked;
  if (soundEnabled) {
    // ensure context created on next user interaction
  }
  if (autoSaveEl.checked) saveSettings();
});

volumeEl.addEventListener('input', (e) => {
  const v = parseFloat(e.target.value);
  setVolume(v);
  if (autoSaveEl.checked) saveSettings();
});

// Menu open/close & parameters
openMenuBtn.addEventListener('click', () => {
  menuOverlay.classList.remove('hidden');
  menuOverlay.setAttribute('aria-hidden', 'false');
});
closeMenuBtn.addEventListener('click', () => {
  menuOverlay.classList.add('hidden');
  menuOverlay.setAttribute('aria-hidden', 'true');
});

gameModeEl.addEventListener('change', () => {
  const m = gameModeEl.value;
  firstToParams.classList.toggle('hidden', m !== 'firstTo');
  livesParams.classList.toggle('hidden', m !== 'lives');
  timedParams.classList.toggle('hidden', m !== 'timed');
});

applyMenuBtn.addEventListener('click', () => {
  setModeFromUI();
  applyDifficulty();
  if (autoSaveEl.checked) saveSettings();
  startMatch();
  menuOverlay.classList.add('hidden');
  menuOverlay.setAttribute('aria-hidden', 'true');
});

// Click / tap canvas serve
canvas.addEventListener('click', (e) => {
  if (!running) {
    running = true;
    infoEl.textContent = '';
    if (!audioCtx) ensureAudioContext();
  }
});

// Unlock audio on first user gesture
function unlockAudioOnGesture() {
  if (!audioCtx) {
    try {
      ensureAudioContext();
      const o = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      g.gain.value = 0;
      o.connect(g);
      g.connect(masterGain);
      o.start(0);
      o.stop(audioCtx.currentTime + 0.02);
    } catch (e) {
      // ignore
    }
  }
  window.removeEventListener('mousedown', unlockAudioOnGesture);
  window.removeEventListener('touchstart', unlockAudioOnGesture);
  window.removeEventListener('keydown', unlockAudioOnGesture);
}
window.addEventListener('mousedown', unlockAudioOnGesture);
window.addEventListener('touchstart', unlockAudioOnGesture, {passive:true});
window.addEventListener('keydown', unlockAudioOnGesture);

// Load saved settings (if any)
(function initFromStorage() {
  const ok = loadSettings();
  if (ok) {
    // apply UI loaded values to variables
    difficultyEl.dispatchEvent(new Event('change'));
    keyboardOnlyEl.dispatchEvent(new Event('change'));
    soundToggleEl.dispatchEvent(new Event('change'));
    volumeEl.dispatchEvent(new Event('input'));
    // reflect mode-specific fields visibility
    gameModeEl.dispatchEvent(new Event('change'));
  }
})();

// If no saved settings, ensure defaults applied
applyDifficulty();
setModeFromUI();
startMatch();
updateScore();
if (!('ontouchstart' in window)) {
  mobileControlsEl.classList.add('hidden');
}
if (keyboardOnlyEl.checked) mobileControlsEl.classList.add('hidden');

// Game loop
function gameLoop(ts) {
  const dt = ts - (lastTime || ts);
  lastTime = ts;

  step(dt);
  draw();

  requestAnimationFrame(gameLoop);
}
requestAnimationFrame(gameLoop);